//package com.example.fragmenttest;
//
//import android.os.AsyncTask;
//
//import java.net.HttpURLConnection;
//import java.net.URL;
//
//public class Connection extends AsyncTask {
//
//
//    @Override
//    protected String doInBackground(Object[] objects){
//
//        String severURL = "http://localhost:8080/" + objects[1]; //그거 1개
//        try{
//            URL url = new URL(serverURL);
//            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
//
//
//
//        }
//
//    }
//
//}
